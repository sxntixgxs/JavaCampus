package infrastructure.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConfig {
    private static final String URL = "jdbc:mysql://viaduct.proxy.rlwy.net:57205/railway";
    private static final String USER = "root";
    private static final String PASSWORD = "FVIdAEAAfIhVvoZqTCYYIMdpKGLrAreJ";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
